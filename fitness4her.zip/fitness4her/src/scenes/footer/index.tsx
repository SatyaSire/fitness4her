import Logo from "@/assets/Logo.png";

const Footer = () => {
  return (
    <footer className="bg-primary-100 py-16">
      <div className="justify-content mx-auto w-5/6 gap-16 md:flex">
        <div className="mt-16 basis-1/2 md:mt-0">
          <img alt="logo" src={Logo} />
          <p className="my-5">
          Empowering women through personalized fitness solutions. Connect with us for the latest updates, class schedules, and exclusive offers. Our state-of-the-art facilities and expert trainers are dedicated to helping you achieve your health and wellness goals. Join our community and take the first step toward a stronger, healthier you.
          </p>
          <p>© Fitness4Her All Rights Reserved.</p>
        </div>
        <div className="mt-16 basis-1/4 md:mt-0">
          <h4 className="font-bold">Links</h4>
          <p className="my-5">Resources</p>
          <p className="my-5">Fitness Blogs</p>
          <p>Group Training</p>
        </div>
        <div className="mt-16 basis-1/4 md:mt-0">
          <h4 className="font-bold">Contact Us</h4>
          <p className="my-5">Get in touch with us for more information or inquiries.</p>
          <p>(+91) 1234567890</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

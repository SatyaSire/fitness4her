import { SelectedPage, ClassType } from "@/shared/types";
import image1 from "@/assets/image1.png";
import image2 from "@/assets/image2.png";
import image3 from "@/assets/image3.png";
import image4 from "@/assets/image4.png";
import image5 from "@/assets/image5.png";
import image6 from "@/assets/image6.png";
import { motion } from "framer-motion";
import HText from "@/shared/HText";
import Class from "./Class";

const classes: Array<ClassType> = [
  {
    name: "Weight Training Classes",
    description:
    "Our weight training classes are crafted to help you build strength and reach your fitness goals. With expert guidance, you'll engage in effective exercises that enhance muscle growth and endurance. Experience a supportive environment with personalized instruction to maximize your results. Join us and take your fitness to the next level with our focused weight training program.",
    image: image1,
  },
  {
    name: "Yoga Classes",
    image: image2,
    description:
    "Join our yoga classes to enhance flexibility, balance, and mindfulness. Our skilled instructors lead you through a variety of poses and techniques, tailored to all levels. Experience tranquility and improved well-being in a supportive environment that fosters personal growth. Embrace the journey to a healthier body and mind with our rejuvenating yoga sessions.",
  },
  {
    name: "Core Strength",
    description:
      "Strengthen your core with our specialized classes designed to enhance stability and power. Through targeted exercises and expert guidance, you'll build a solid foundation that supports overall fitness and improves performance. Join us to develop a stronger, more resilient core and achieve your fitness goals with confidence.",
    image: image3,
  },
  {
    name: "Free Weight",
    description:
      "Unlock your strength potential with our free weight classes. Our expert trainers guide you through various exercises to enhance muscle growth and overall fitness. Enjoy a versatile workout experience that challenges your body and helps you achieve your fitness goals with personalized support. Join us to elevate your strength training routine with free weights.",
    image: image4,
  },
  {
    name: "Pilates Classes",
    image: image5,
    description: 
    "Experience the benefits of Pilates with our expertly led classes designed to enhance core strength, flexibility, and posture. Through controlled movements and focused breathing, you'll improve muscle tone and overall body alignment. Our classes cater to all skill levels, offering personalized attention in a supportive environment. Join us to achieve a balanced and stronger body with Pilates.",
  },
  {
    name: "Group Training",
    description:
      "Boost your fitness journey with our dynamic group training sessions. Engage in high-energy workouts designed to challenge and motivate you alongside others. Led by expert trainers, these classes foster camaraderie and provide a variety of exercises to enhance strength, endurance, and overall fitness. Join us to enjoy a fun and supportive group environment while achieving your fitness goals.",
    image: image6,
  },
];

type Props = {
  setSelectedPage: (value: SelectedPage) => void;
};

const OurClasses = ({ setSelectedPage }: Props) => {
  return (
    <section id="ourclasses" className="w-full bg-primary-100 py-40">
      <motion.div
        onViewportEnter={() => setSelectedPage(SelectedPage.OurClasses)}
      >
        <motion.div
          className="mx-auto w-5/6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5 }}
          variants={{
            hidden: { opacity: 0, x: -50 },
            visible: { opacity: 1, x: 0 },
          }}
        >
          <div className="md:w-3/5">
            <HText>OUR CLASSES</HText>
            <p className="py-5">
              Explore our diverse range of classes designed to fit all fitness levels and preferences. From dynamic group sessions to personalized training, each class is crafted to help you achieve your fitness goals effectively. Our expert instructors ensure that every session is engaging and tailored to your needs, whether you're looking to improve strength, flexibility, or overall well-being. Join us and experience how our classes can transform your fitness journey with motivation and support.
            </p>
          </div>
        </motion.div>
        <div className="mt-10 h-[353px] w-full overflow-x-auto overflow-y-hidden">
          <ul className="w-[2800px] whitespace-nowrap">
            {classes.map((item: ClassType, index) => (
              <Class
                key={`${item.name}-${index}`}
                name={item.name}
                description={item.description}
                image={item.image}
              />
            ))}
          </ul>
        </div>
      </motion.div>
    </section>
  );
};

export default OurClasses;
